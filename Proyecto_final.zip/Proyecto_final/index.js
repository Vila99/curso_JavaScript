const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const questions = [
    {
        question: "¿Cuál es tu deporte favorito?",
        options: ["1) Fútbol", "2) Básquet", "3) Golf", "4) Natación"],
        answerType: "text"
    },
    {
        question: "¿Cuál es tu número favorito?",
        options: ["1) Uno", "2) Dos", "3) Tres", "4) Cuatro"],
        answerType: "number"
    },
    {
        question: "¿Qué lenguaje de programación prefieres?",
        options: ["1) JavaScript", "2) Python", "3) Java", "4) C++"],
        answerType: "text"
    },
    {
        question: "¿Donde sueles programar?",
        options: ["1) Estudio", "2) Salon", "3) Cocina", "4) Oficina"],
        answerType: "text"
    }
];

let answers = [];

const askQuestion = (index) => {
    if (index < questions.length) {
        // Presenta la pregunta y sus opciones
        console.log(questions[index].question);
        questions[index].options.forEach(option => console.log(option));
        
        // Pregunta al usuario por una opción
        rl.question("Por favor, selecciona una opción (1-4): ", (answer) => {
            // Validación de la respuesta para preguntas numéricas
            if (questions[index].answerType === "number" && isNaN(answer)) {
                console.log("Por favor, introduce un número válido.");
                askQuestion(index);  // Repite la pregunta
            } else if (answer < 1 || answer > 4) {
                // Validación para respuestas fuera del rango esperado
                console.log("Por favor, selecciona una opción válida (1-4).");
                askQuestion(index);  // Repite la pregunta
            } else {
                // Guarda la respuesta y pasa a la siguiente pregunta
                answers.push(answer);
                askQuestion(index + 1);  // Llama a la función con el siguiente índice
            }
        });
    } else {
        // Todas las preguntas han sido respondidas, cerrar readline y mostrar resultados
        rl.close();
        showResults();
    }
};


const showResults = () => {
    console.log("\nResumen de respuestas:");
    answers.forEach((answer, index) => {
        console.log(`${questions[index].question} Tu respuesta: ${questions[index].options[answer - 1]}`);
    });
};

askQuestion(0);
